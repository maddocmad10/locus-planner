# Phase 2 — Desktop LAN sync API

This phase adds a desktop-hosted, versioned HTTP API without changing the planner's navigation or existing feature flows.

## API surface

- `GET /api/v1/health` — version/status probe; no authentication.
- `POST /api/v1/pairing/exchange` — exchanges the five-minute, one-use pairing code for a random bearer token. Request JSON: `{"code":"A1B2C3D4","deviceId":"client-install-uuid","name":"My phone"}`.
- `GET /api/v1/snapshot?limit=100` — reads one page of the initial state. The response carries an opaque `nextAfter` token; pass it as `after=<token>` on the next page. `offset` is still accepted for older phones, but it is positional and can skip a row if the state changes between pages.
- `GET /api/v1/changes?after=0&limit=100` — reads ordered outbox records after the supplied numeric cursor. Requires `Authorization: Bearer <token>`.
- `POST /api/v1/changes/ack` — persists the paired client's acknowledged desktop cursor. Request JSON: `{"cursor":123}`.
- `POST /api/v1/changes/apply` — applies up to 200 supported inbound mutations in one database transaction and suppresses outbox echo. Requires the same bearer authentication. Request JSON: `{"changes":[{"entityType":"event","entityId":"...","operation":"upsert","payload":{"id":"...","title":"...","description":null,"start_time":...,"end_time":null,"category":"general","has_reminder":0,"reminder_minutes":10,"recurrence_rule":null}}]}`.

Supported entities are `project`, `event`, `project_task`, `todo`, `todo_completion`, `diary_entry`, `habit`, `habit_log`, `daily_plan`, `daily_plan_item`, `task_schedule_block`, `saved_filter`, `planning_preference`, `working_hours`, `working_break`, `project_status`, `project_milestone` and `task_dependency`. The Android MVP performs an initial snapshot on first sync. Sync runs on demand and automatically when the Android app is opened or returns to the foreground (at most once a minute); it does not run while the phone app is closed. Conflicts are resolved per row by version (see "Conflict resolution" below) rather than by a conflict-resolution UI. The caller must apply changes durably before acknowledging the cursor. Project upserts should precede task upserts; a batch is atomic, so a foreign-key failure rejects the batch.

The Phase 2 planning tables also keep a real business `updated_at`, so their sync version travels as `sync_updated_at` in the payload. `task_schedule_block` snapshots sort after both `todo` and `project_task`, and `saved_filter`, `planning_preference`, `working_hours` and `working_break` sort at the end of the snapshot. A build that predates these entities ignores them instead of rejecting the batch. Deleting a to-do or project checklist task cascades its schedule blocks, which arrive as ordinary block tombstones.

Phase 3 adds the workflow fields to `project_task` payloads and the `project_status`, `project_milestone` and `task_dependency` entities. Dependencies sort after tasks and are applied only when both endpoint tasks exist and belong to the same project. An orphan endpoint or a cycle is reported as a rejected change with a diagnostic rather than silently discarded. Migration 19 rotates the sync epoch so a previously paired phone fetches a fresh snapshot.

Phase 4 adds `is_important`/`urgency_override` to `todo` payloads and `urgency_window_days` to `planning_preference`. Older peers receive neutral defaults; no epoch rotation is needed because the defaults preserve the pre-upgrade meaning and later edits queue normally.

The My Day tables store a real business `updated_at`, so their sync version travels as `sync_updated_at` in the payload; the two values never overwrite each other. Habit logs, daily plans and plan items use deterministic UUIDv5 ids derived from their natural key (`habit_log:<habit>:<day>`, `daily_plan:<day>`, `daily_plan_item:<plan>:todo|task:<id>`). Two devices that create the same row while offline therefore agree on its id instead of fighting a unique index. Existing habit logs with random ids still converge by the lowest-id rule: when the same habit/day arrives with a different id, the lower id wins and the losing local row is deleted without a tombstone. Migration 14 rotates `sync.epoch` so a phone paired before habit sync receives a fresh snapshot including pre-existing habits and logs.


## Run on Windows

1. Back up the app database.
2. From the project root, run:
   ```powershell
   flutter pub get
   dart format lib/core/services/lan_sync_server.dart lib/core/providers/service_providers.dart lib/features/settings/presentation/settings_page.dart test/lan_sync_server_test.dart
   flutter analyze
   flutter test
   ```
3. Launch Locus, open **Settings → Device Sync (LAN)**, and enable the server. The server listens on all IPv4 interfaces on TCP port `43821` over HTTPS; a one-time pairing code, a QR code and the computer's security fingerprint appear, and the code expires in five minutes.
4. Run `ipconfig` on the desktop and find its Wi-Fi IPv4 address. On the second device, replace `192.168.x.x` below with that address. Both devices must be on a trusted private Wi-Fi network; guest Wi-Fi/client isolation can block connections.
5. From a second device with `curl` available, check the health endpoint:
   ```sh
   curl -k https://192.168.x.x:43821/api/v1/health
   ```
6. Pair the second device, replacing `A1B2C3D4` with the code visible in desktop Settings:
   ```sh
   curl -k -X POST https://192.168.x.x:43821/api/v1/pairing/exchange      -H "Content-Type: application/json"      -d '{"code":"A1B2C3D4","deviceId":"phone-install-uuid","name":"Test phone"}'
   ```
   Save the returned token securely. The code is one-use. For a new pairing, click **New pairing code** in desktop Settings.
7. Prove authentication: a request without a token should return `401`; a request with the token should return `200`:
   ```sh
   curl -k -i https://192.168.x.x:43821/api/v1/changes
   curl -k -i https://192.168.x.x:43821/api/v1/changes      -H "Authorization: Bearer YOUR_TOKEN"      -H "Accept: application/json"
   ```
8. Create or edit a supported entity in the desktop app, then repeat the authenticated changes request with `?after=0&limit=100`. The resulting record should appear in `changes`. A client should only call `/changes/ack` after it has durably applied the changes.
9. Revoke the paired client from desktop Settings and verify its previously issued token now gets `401`.
10. Disable LAN sync when not needed.

If Windows Firewall blocks the connection, allow inbound TCP `43821` only on the **Private** profile. Do not expose this port on Public networks.

## Security and current scope

Pairing secrets are short-lived and single-use; bearer tokens are generated with a cryptographically secure random source and only their SHA-256 digests are persisted. Tokens can be revoked from Settings. Request bodies are size-limited and change batches are capped.

All traffic is HTTPS. On first start the desktop creates a self-signed certificate. The certificate (public) is kept in the database settings, which are excluded from backups; the private key is kept in the operating system's protected storage (`flutter_secure_storage`), so copying the database file or a cloud-synced AppData folder does not copy the key. A key left in the database by an earlier version is moved on first start. If protected storage cannot be used, the key stays in the database so sync keeps working and a note is written to stderr. The fingerprint stays the same across restarts and address changes. If the protected key is lost (for example Windows credentials were reset), a new certificate is created and phones must pair again. A certificate for a bare IP address cannot come from a public authority, so phones do not use one. They **pin** the certificate instead: the pairing QR code carries the desktop's address, the one-time code and the SHA-256 fingerprint of its certificate, and the phone connects only to a server presenting exactly that certificate, with no system or built-in roots trusted. Nothing, including the pairing code, is sent to any other server. This protects the bearer token and the data from other devices on the same Wi-Fi, including a device impersonating the desktop.

Without a camera, a phone can pair by address and code. It first connects without sending anything, reads the certificate fingerprint, and asks the user to confirm that it matches the fingerprint shown in desktop Settings before pairing. Compare it carefully: that comparison is what protects a manual pairing.

`curl -k` in the examples below skips certificate checking, which is acceptable for a quick local test on a network you trust but is exactly what a phone does not do.

Pairing a device that is already paired (after **Forget pairing**, a reinstall, or the upgrade to HTTPS) replaces its previous entry and token. The one-time code, which is only visible on the desktop, is what authorises it. **New pairing code** in desktop Settings issues a fresh code and clears the failed-attempt count, so wrong guesses from the network cannot block pairing until the next restart.

Still true: do not use public/guest Wi-Fi or port-forward this API to the internet. Anyone who can reach the port can attempt to guess the pairing code while one is active (twenty wrong guesses stop pairing until a new code is issued), and a TLS identity that is lost or replaced makes every phone pair again.

## Conflict resolution

Schema version 9 adds `sync_row_versions`, one row per synced entity, kept up to date by the same SQLite triggers that fill the outbox. Each payload carries the row's version as `updated_at` (epoch milliseconds) and each change carries the originating `deviceId`.

- An incoming change is applied only if its version is newer than the local one. An exact tie is broken by device ID so both devices choose the same winner; replaying an already-applied change is a no-op.
- Deletes are versioned tombstones, so a stale upsert cannot bring back a row that was deleted later.
- A local edit is always at least one version above the row's previous version, so editing after receiving a change from a device with a fast clock still wins over it.
- Both the desktop API (`/changes/apply`) and the Android client use `SyncChangeApplier`, so the rules are identical in each direction. `/changes/apply` also reports `applied` and `skipped` counts.
- Rows that existed before the upgrade have no version until they are next edited, and an incoming change always wins over an unversioned row. Changes from a peer that predates versioning are applied unconditionally.
- Versions come from each device's wall clock. If two devices edit the same row at nearly the same moment, a clock that is far off can pick the wrong winner, so keep device clocks set automatically.
- Diary entries are also unique per date. If two different entries claim one date, the entry with the lowest ID keeps its ID on both devices and the other entry's text is merged into it, after a "merged from another device" divider. Both devices compute the same merged text and the merge is idempotent, so it settles after one extra exchange and nothing the user wrote is discarded. Moods are not merged: the surviving entry keeps its own mood.

## Epoch check and outbox pruning

**Epoch.** Each desktop database creates a random `sync.epoch` the first time it opens. The server returns it when pairing, in snapshots and in `/changes` responses, and the phone sends it back in the `X-Locus-Epoch` header on every other request. If the header does not match, the server answers `409 epoch_mismatch`. This catches a reinstalled or rebuilt desktop, whose outbox ids restart and would otherwise make the phone's cursors meaningless. The epoch is excluded from backups on purpose, so restoring a backup never brings back an old history. The snapshot endpoint is exempt, because it is how a phone recovers.

**Cursor checks.** `/changes` also answers `409 cursor_ahead` if the phone's cursor is beyond anything the desktop ever issued, and `409 resync_required` if the phone's cursor points into rows that have been pruned.

**Resync.** On any of those three `409` errors the phone forgets its position, fetches a fresh snapshot, and pushes its own full state (live rows and delete tombstones) back to the desktop before resuming. Because both sides compare row versions, the newer edit wins and nothing on the phone is lost. It retries once; if the desktop still disagrees the error is shown.

**Pruning.**
- Desktop: at startup (even if LAN sync has never been started), after each acknowledgement, on server start and when a phone is revoked, outbox rows that every paired phone has acknowledged are deleted. With no paired phones the whole outbox is cleared, since a newly paired phone starts from a snapshot. Rows older than 60 days are deleted even if a phone never acknowledged them, so a lost phone cannot pin the outbox forever; that phone gets `resync_required` when it next connects.
- Phone: after a successful push, outbox rows up to the pushed cursor are deleted. At startup, an unpaired phone clears its whole outbox, since it has no desktop to send changes to. A paired phone is never cleared this way, and neither is a phone that must pair again after the move to HTTPS.
- `sync.outbox.pruned_through` records the highest pruned id. Outbox ids are `AUTOINCREMENT`, so pruning never reuses an id.

Not pruned yet: delete tombstones in `sync_row_versions`. They are small, and keeping them stops a stale device from resurrecting deleted rows.

## Screen refresh and reminders after sync

Synced rows are written with raw SQL so that the outbox triggers can be suppressed. Drift cannot see raw SQL, so its `watch()` streams, which every screen is built on, would not refresh on their own. After each applied batch `SyncChangeApplier` calls `markTablesUpdated` for the tables it changed (plus the tables a project delete cascades to), on both the desktop and the phone. Changes that were skipped as stale do not trigger a refresh.

Event reminders are in-memory timers owned by `EventRepository`, which sync bypasses. `LanSyncServer.onChangesApplied` is called after a phone's changes are committed, and `main.dart` uses it to call `EventRepository.rescheduleReminders` for each changed event: a deleted event has its timer cancelled, and a new or edited one is re-armed from its stored time. A failure in this hook is logged and never fails the sync.

The Android app also has native reminders. `MobileReminderService` watches the events table and hands Android a rolling list of upcoming reminders, so an event that arrives from the desktop notifies the phone even when the app is closed. See `docs/PHASE_3_ANDROID_MVP.md` for the reminder window and permission details.

## Finding the desktop again (discovery)

A phone saves the desktop's address when it pairs, and routers can hand the desktop a new one. When the saved address does not answer (or answers with another certificate), the phone broadcasts a short UDP message (`locus-discover/1`) on port **43822**. A running desktop replies, to the sender only, with its HTTPS port and the SHA-256 fingerprint of its certificate. The phone ignores any reply whose fingerprint is not the one it pinned, saves the new address, and retries once.

The reply is a hint about *where* to connect and contains nothing secret. The connection that follows is still pinned to the certificate and still needs the bearer token, so a device that answers falsely can at worst make the attempt fail. The desktop answers only senders on private (or loopback) addresses, ignores anything that is not exactly the request, and sends at most 20 replies per second. If UDP 43822 is already in use, discovery is skipped and sync works by address as before. Windows Firewall asks about both TCP and UDP for the app the first time; allow it on **Private** networks only. Discovery cannot cross subnets, such as a guest network or VLAN.

## Paired-client bookkeeping

The paired phones and their acknowledged cursors are stored as one JSON setting. Every change to it (pairing, acknowledging, revoking) is serialised inside the server, so overlapping requests cannot overwrite each other.
