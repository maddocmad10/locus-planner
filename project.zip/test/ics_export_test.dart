import 'package:flutter_test/flutter_test.dart';
import 'package:locus_planner/core/db/app_database.dart';
import 'package:locus_planner/core/services/data_export_service.dart';

Event _event({
  String id = 'e1',
  String title = 'Meeting',
  String? description,
  DateTime? start,
  DateTime? end,
  String category = 'work',
  String? recurrenceRule,
  DateTime? recurrenceEnd,
  bool allDay = false,
  String recurrenceExceptions = '[]',
  bool hasReminder = false,
}) {
  return Event(
    id: id,
    title: title,
    description: description,
    descriptionFormat: 'plain',
    startTime: start ?? DateTime.utc(2026, 10, 5, 16, 30),
    endTime: end,
    category: category,
    hasReminder: hasReminder,
    reminderMinutes: 10,
    recurrenceRule: recurrenceRule,
    allDay: allDay,
    recurrenceEnd: recurrenceEnd,
    recurrenceExceptions: recurrenceExceptions,
  );
}

void main() {
  final now = DateTime.utc(2026, 10, 5, 12);

  test('produces a well-formed calendar with CRLF line endings', () {
    final ics = DataExportService.buildIcsCalendar([_event()], now: now);

    expect(ics, startsWith('BEGIN:VCALENDAR\r\n'));
    expect(ics, endsWith('END:VCALENDAR\r\n'));
    expect(
      RegExp(r'(?<!\r)\n').hasMatch(ics),
      isFalse,
      reason: 'bare LF found',
    );
    expect(ics, contains('UID:e1@locusplanner\r\n'));
  });

  test('writes DTSTAMP and UTC start/end times', () {
    final ics = DataExportService.buildIcsCalendar([
      _event(end: DateTime.utc(2026, 10, 5, 17, 30)),
    ], now: now);
    expect(ics, contains('DTSTAMP:20261005T120000Z\r\n'));
    expect(ics, contains('DTSTART:20261005T163000Z\r\n'));
    expect(ics, contains('DTEND:20261005T173000Z\r\n'));
  });

  test('omits DTEND when the event has no end time', () {
    final ics = DataExportService.buildIcsCalendar([_event()], now: now);
    expect(ics, isNot(contains('DTEND')));
  });

  test('escapes backslashes, semicolons, commas and newlines', () {
    final ics = DataExportService.buildIcsCalendar([
      _event(title: r'A, B; C\D', description: 'line1\nline2'),
    ], now: now);
    expect(ics, contains(r'SUMMARY:A\, B\; C\\D'));
    expect(ics, contains(r'DESCRIPTION:line1\nline2'));
  });

  test('folds long lines to 75 octets and unfolds back to the original', () {
    final title = 'x' * 200;
    final ics = DataExportService.buildIcsCalendar([
      _event(title: title),
    ], now: now);

    for (final line in ics.split('\r\n')) {
      expect(line.codeUnits.length, lessThanOrEqualTo(75));
    }
    expect(ics.replaceAll('\r\n ', ''), contains('SUMMARY:$title'));
  });

  test('folding never splits a multi-byte character', () {
    final title = 'é' * 100; // 2 bytes each in UTF-8
    final ics = DataExportService.buildIcsCalendar([
      _event(title: title),
    ], now: now);

    expect(ics.replaceAll('\r\n ', ''), contains('SUMMARY:$title'));
    for (final line in ics.split('\r\n')) {
      // 'é' is a single UTF-16 unit, so octets = units + count('é').
      final octets = line.codeUnits.length + 'é'.allMatches(line).length;
      expect(octets, lessThanOrEqualTo(75));
    }
  });

  test(
    'adds RDATEs for month-end occurrences that RRULE would otherwise skip',
    () {
      final ics = DataExportService.buildIcsCalendar([
        _event(start: DateTime(2026, 1, 31, 16, 30), recurrenceRule: 'monthly'),
      ], now: now);
      expect(ics, contains('RRULE:FREQ=MONTHLY\r\n'));
      expect(ics, contains('RDATE:20260228T163000'));
      expect(ics, contains(',20260430T163000'));
    },
  );

  test('writes an RRULE for recurring events and omits it otherwise', () {
    final ics = DataExportService.buildIcsCalendar([
      _event(recurrenceRule: 'weekdays'),
    ], now: now);
    expect(ics, contains('RRULE:FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR\r\n'));
    expect(
      DataExportService.buildIcsCalendar([_event()], now: now),
      isNot(contains('RRULE')),
    );
  });
  test(
    'weekday recurrence starting on weekend exports first real occurrence',
    () {
      final ics = DataExportService.buildIcsCalendar([
        _event(start: DateTime(2026, 10, 10, 9), recurrenceRule: 'weekdays'),
      ], now: now);
      expect(ics, contains('DTSTART:20261012T090000'));
    },
  );

  test('writes UNTIL and EXDATE for a bounded series', () {
    final ics = DataExportService.buildIcsCalendar([
      _event(
        start: DateTime(2026, 10, 5, 9),
        recurrenceRule: 'daily',
        recurrenceEnd: DateTime.utc(2026, 12, 28, 9),
        recurrenceExceptions: '["2026-10-07","2026-10-08"]',
      ),
    ], now: now);

    expect(ics, contains('RRULE:FREQ=DAILY;UNTIL=20261228T090000Z'));
    expect(ics, contains('EXDATE:20261007T090000,20261008T090000'));
  });

  test('writes VALUE=DATE and omits reminders for all-day events', () {
    final ics = DataExportService.buildIcsCalendar([
      _event(
        start: DateTime(2026, 10, 5),
        end: DateTime(2026, 10, 6),
        recurrenceRule: 'daily',
        recurrenceEnd: DateTime(2026, 10, 9),
        recurrenceExceptions: '["2026-10-07"]',
        allDay: true,
        hasReminder: true,
      ),
    ], now: now);

    expect(ics, contains('DTSTART;VALUE=DATE:20261005'));
    expect(ics, contains('DTEND;VALUE=DATE:20261006'));
    expect(ics, contains('RRULE:FREQ=DAILY;UNTIL=20261009'));
    expect(ics, contains('EXDATE:20261007'));
    expect(ics, isNot(contains('BEGIN:VALARM')));
  });
}
