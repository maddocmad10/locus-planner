import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../../../core/db/app_database.dart';
import '../../../core/services/error_log_service.dart';
import '../../../core/providers/database_provider.dart';
import '../data/focus_repository.dart';
import '../../../core/utils/app_clock.dart';

enum FocusTimerStatus { idle, running, paused, saving, saveFailed }

@immutable
class FocusTimerState {
  const FocusTimerState({
    this.selectedMinutes = 25,
    this.remainingSeconds = 25 * 60,
    this.status = FocusTimerStatus.idle,
    this.projectId,
    this.completedCount = 0,
    this.lastCompletedMinutes = 0,
    this.isRestoring = false,
    this.recoveryNotice,
  });

  final int selectedMinutes;
  final int remainingSeconds;
  final FocusTimerStatus status;
  final String? projectId;

  /// Incremented every time a session finishes and has been saved. The UI
  /// listens to this to show a "well done" message.
  final int completedCount;
  final int lastCompletedMinutes;
  final bool isRestoring;
  final String? recoveryNotice;

  bool get isRunning => status == FocusTimerStatus.running;

  /// Length, project, and a fresh start would throw away an unsaved finish.
  bool get locksSessionSetup =>
      status == FocusTimerStatus.running ||
      status == FocusTimerStatus.saving ||
      status == FocusTimerStatus.saveFailed;

  double get progress {
    final totalSeconds = selectedMinutes * 60;
    if (totalSeconds <= 0) return 0.0;
    return (remainingSeconds / totalSeconds).clamp(0.0, 1.0);
  }

  FocusTimerState copyWith({
    int? selectedMinutes,
    int? remainingSeconds,
    FocusTimerStatus? status,
    String? projectId,
    bool clearProject = false,
    int? completedCount,
    int? lastCompletedMinutes,
    bool? isRestoring,
    String? recoveryNotice,
    bool clearRecoveryNotice = false,
  }) {
    return FocusTimerState(
      selectedMinutes: selectedMinutes ?? this.selectedMinutes,
      remainingSeconds: remainingSeconds ?? this.remainingSeconds,
      status: status ?? this.status,
      projectId: clearProject ? null : (projectId ?? this.projectId),
      completedCount: completedCount ?? this.completedCount,
      lastCompletedMinutes: lastCompletedMinutes ?? this.lastCompletedMinutes,
      isRestoring: isRestoring ?? this.isRestoring,
      recoveryNotice: clearRecoveryNotice
          ? null
          : (recoveryNotice ?? this.recoveryNotice),
    );
  }
}

/// Owns the focus countdown. It lives in the provider scope (not in a widget),
/// so switching tabs, or the Focus page being rebuilt, no longer cancels the
/// timer or loses the session.
///
/// The countdown is derived from an end timestamp rather than by decrementing a
/// counter, so it stays accurate if ticks are delayed (minimised window,
/// machine sleep).
class FocusTimerNotifier extends Notifier<FocusTimerState> {
  Timer? _ticker;
  DateTime? _endsAt;
  DateTime? _sessionStart;
  String? _sessionId;
  bool _disposed = false;
  static const _persistedKey = AppDatabase.focusSessionSettingKey;
  static const _pendingCompletionKey =
      AppDatabase.focusPendingCompletionSettingKey;
  static const _defaultState = FocusTimerState(isRestoring: true);
  final _uuid = const Uuid();
  late final Future<void> _restoreFuture;

  @override
  FocusTimerState build() {
    ref.onDispose(() {
      _disposed = true;
      _ticker?.cancel();
    });
    _restoreFuture = _restorePersistedState();
    unawaited(_restoreFuture);
    return _defaultState;
  }

  void start() {
    if (state.isRestoring) return;
    // A failed save stays on screen until the user retries or resets. Starting
    // a new session here would look like the finished one had been stored.
    if (state.locksSessionSetup) return;
    final now = AppClock.now();
    _sessionStart ??= now;
    _sessionId ??= _uuid.v4();
    _endsAt = now.add(Duration(seconds: state.remainingSeconds));
    state = state.copyWith(status: FocusTimerStatus.running);

    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(milliseconds: 250), (_) => _tick());
    unawaited(_persistState());
  }

  void pause() {
    if (state.isRestoring) return;
    if (!state.isRunning) return;
    _ticker?.cancel();
    final remaining = _remainingNow();
    if (remaining <= 0) {
      unawaited(_complete());
      return;
    }
    state = state.copyWith(
      status: FocusTimerStatus.paused,
      remainingSeconds: remaining,
    );
    _endsAt = null;
    unawaited(_persistState());
  }

  void reset() {
    if (state.isRestoring || state.status == FocusTimerStatus.saving) return;
    _ticker?.cancel();
    _endsAt = null;
    _sessionStart = null;
    _sessionId = null;
    state = state.copyWith(
      status: FocusTimerStatus.idle,
      remainingSeconds: state.selectedMinutes * 60,
      clearRecoveryNotice: true,
    );
    unawaited(_clearPersistedState());
  }

  /// Changing the length discards any session in progress, so the UI only
  /// offers it while the timer is not running.
  void setDuration(int minutes) {
    if (state.isRestoring) return;
    if (state.locksSessionSetup) return;
    minutes = minutes.clamp(1, 240).toInt();
    _endsAt = null;
    _sessionStart = null;
    _sessionId = null;
    state = state.copyWith(
      selectedMinutes: minutes,
      remainingSeconds: minutes * 60,
      status: FocusTimerStatus.idle,
    );
    unawaited(_clearPersistedState());
  }

  void setProject(String? projectId) {
    if (state.isRestoring) return;
    if (state.status == FocusTimerStatus.saving ||
        state.status == FocusTimerStatus.saveFailed) {
      return;
    }
    state = projectId == null
        ? state.copyWith(clearProject: true)
        : state.copyWith(projectId: projectId);
    unawaited(_persistState());
  }

  Future<void> _persistState() async {
    if (_disposed) return;
    final db = ref.read(databaseProvider);
    final payload = <String, dynamic>{
      'selectedMinutes': state.selectedMinutes,
      'remainingSeconds': state.isRunning
          ? _remainingNow()
          : state.remainingSeconds,
      'status': state.status.name,
      'projectId': state.projectId,
      'sessionId': _sessionId,
      'sessionStart': _sessionStart?.toIso8601String(),
      'endsAt': _endsAt?.toIso8601String(),
    };
    await db.setSetting(_persistedKey, jsonEncode(payload));
  }

  Future<void> _persistPendingCompletion({
    required String sessionId,
    required int durationMinutes,
    required String? projectId,
    required DateTime startedAt,
    int attempts = 0,
  }) async {
    if (_disposed) return;
    final payload = <String, dynamic>{
      'sessionId': sessionId,
      'durationMinutes': durationMinutes,
      'projectId': projectId,
      'startedAt': startedAt.toIso8601String(),
      'attempts': attempts,
    };
    await ref
        .read(databaseProvider)
        .setSetting(_pendingCompletionKey, jsonEncode(payload));
  }

  Future<void> _clearPersistedState() async {
    if (_disposed) return;
    await ref.read(databaseProvider).deleteSetting(_persistedKey);
  }

  Future<void> _restorePersistedState() async {
    try {
      final db = ref.read(databaseProvider);

      // Migrate recovery records written by older versions under the active
      // timer key. Recovery and active timer state must never share a setting.
      final legacyRaw = await db.getSetting(_persistedKey);
      final pendingRaw = await db.getSetting(_pendingCompletionKey);
      if (pendingRaw == null && legacyRaw != null) {
        try {
          final legacy = jsonDecode(legacyRaw);
          if (legacy is Map<String, dynamic>) {
            final nested =
                legacy['pendingCompletion'] ?? legacy['focus_pending_recovery'];
            if (nested is Map<String, dynamic>) {
              await db.setSetting(_pendingCompletionKey, jsonEncode(nested));
              await db.deleteSetting(_persistedKey);
              // This was a recovery record, not an active timer.
              await _restorePendingCompletion(nested);
              return;
            }
          }
        } catch (e, st) {
          debugPrint('Could not migrate legacy focus recovery: $e\n$st');
        }
      }

      await _restorePendingCompletionFromStorage();
      if (_disposed) return;

      final raw = await db.getSetting(_persistedKey);
      if (raw == null) return;
      final data = jsonDecode(raw);
      if (data is! Map<String, dynamic>) {
        await _clearPersistedState();
        return;
      }

      final rawMinutes = (data['selectedMinutes'] as num?)?.toInt() ?? 25;
      final minutes = rawMinutes.clamp(1, 240).toInt();
      final rawRemaining =
          (data['remainingSeconds'] as num?)?.toInt() ?? minutes * 60;
      final remaining = rawRemaining.clamp(0, minutes * 60).toInt();
      final projectId = data['projectId'] as String?;
      final sessionId = data['sessionId'] as String?;
      final sessionStart = DateTime.tryParse(
        data['sessionStart'] as String? ?? '',
      );
      final endsAt = DateTime.tryParse(data['endsAt'] as String? ?? '');
      final statusName = data['status'] as String? ?? 'idle';
      final status = FocusTimerStatus.values.firstWhere(
        (value) => value.name == statusName,
        orElse: () => FocusTimerStatus.idle,
      );

      _sessionId = sessionId;
      _sessionStart = sessionStart;
      _endsAt = endsAt;
      if (minutes != rawMinutes || remaining != rawRemaining) {
        await _clearPersistedState();
      }

      // Keep the restore gate raised until the whole restore flow finishes.
      // copyWith also preserves counters and any recovery notice already set
      // while processing a pending completion.
      state = state.copyWith(
        selectedMinutes: minutes,
        remainingSeconds: remaining,
        status: status,
        projectId: projectId,
        clearProject: projectId == null,
        isRestoring: true,
      );

      if (status == FocusTimerStatus.running) {
        final left = _remainingNow();
        if (left <= 0) {
          await _complete(showNotification: false);
        } else {
          state = state.copyWith(remainingSeconds: left);
          _ticker?.cancel();
          _ticker = Timer.periodic(
            const Duration(milliseconds: 250),
            (_) => _tick(),
          );
        }
      }
    } catch (e, st) {
      debugPrint('Failed to restore focus timer: $e\n$st');
      await _clearPersistedState();
    } finally {
      if (!_disposed) {
        state = state.copyWith(isRestoring: false);
      }
    }
  }

  Future<void> _restorePendingCompletionFromStorage() async {
    final raw = await ref
        .read(databaseProvider)
        .getSetting(_pendingCompletionKey);
    if (raw == null || _disposed) return;
    dynamic decoded;
    try {
      decoded = jsonDecode(raw);
    } catch (e, st) {
      debugPrint('Invalid pending focus recovery JSON: $e\n$st');
      await ref.read(databaseProvider).deleteSetting(_pendingCompletionKey);
      return;
    }
    if (decoded is! Map<String, dynamic>) {
      await ref.read(databaseProvider).deleteSetting(_pendingCompletionKey);
      return;
    }
    try {
      await _restorePendingCompletion(decoded);
    } catch (e, st) {
      // Keep the recovery record if storage or logging fails. A later startup
      // can retry it rather than silently discarding the completed session.
      debugPrint('Failed to process pending focus recovery: $e\n$st');
    }
  }

  Future<void> _restorePendingCompletion(Map<String, dynamic> pending) async {
    final db = ref.read(databaseProvider);
    final sessionId = pending['sessionId'] as String?;
    final durationMinutes = (pending['durationMinutes'] as num?)?.toInt();
    final projectId = pending['projectId'] as String?;
    final startedAt = DateTime.tryParse(pending['startedAt'] as String? ?? '');
    final attempts = (pending['attempts'] as num?)?.toInt() ?? 0;

    if (sessionId == null ||
        sessionId.trim().isEmpty ||
        durationMinutes == null ||
        durationMinutes < 1 ||
        durationMinutes > 24 * 60 ||
        startedAt == null) {
      await db.deleteSetting(_pendingCompletionKey);
      return;
    }

    if (attempts >= 3) {
      await _logAndDiscardExhaustedRecovery(
        pending: pending,
        reason: 'The recovery record had already exhausted its retries.',
      );
      return;
    }

    try {
      await ref
          .read(focusRepositoryProvider)
          .completeSession(
            sessionId: sessionId,
            durationMinutes: durationMinutes,
            projectId: projectId,
            startedAt: startedAt,
            notify: false,
          );
      await db.deleteSetting(_pendingCompletionKey);
      if (!_disposed) {
        state = state.copyWith(
          completedCount: state.completedCount + 1,
          lastCompletedMinutes: durationMinutes,
        );
      }
    } catch (e, st) {
      final nextAttempts = attempts + 1;
      final failedRecord = <String, dynamic>{
        'sessionId': sessionId,
        'durationMinutes': durationMinutes,
        'projectId': projectId,
        'startedAt': startedAt.toIso8601String(),
        'attempts': nextAttempts,
      };
      if (nextAttempts >= 3) {
        await _logAndDiscardExhaustedRecovery(
          pending: failedRecord,
          reason:
              'The session could not be saved after $nextAttempts attempts. '
              'Last error: $e',
          stackTrace: st,
        );
        return;
      }

      await ErrorLogService.log(e, st);
      await _persistPendingCompletion(
        sessionId: sessionId,
        durationMinutes: durationMinutes,
        projectId: projectId,
        startedAt: startedAt,
        attempts: nextAttempts,
      );
    }
  }

  Future<void> _logAndDiscardExhaustedRecovery({
    required Map<String, dynamic> pending,
    required String reason,
    StackTrace? stackTrace,
  }) async {
    // Include the complete record in the diagnostic entry before removing it.
    // ErrorLogService is deliberately best-effort and never throws.
    await ErrorLogService.log(
      StateError('$reason Pending focus record: ${jsonEncode(pending)}'),
      stackTrace ?? StackTrace.current,
    );
    await ref.read(databaseProvider).deleteSetting(_pendingCompletionKey);
    if (!_disposed) {
      state = state.copyWith(
        recoveryNotice:
            'A focus session could not be saved after 3 attempts. '
            'The recovery details were written to the error log.',
      );
    }
  }

  void clearRecoveryNotice() {
    if (state.recoveryNotice == null) return;
    state = state.copyWith(clearRecoveryNotice: true);
  }

  int _remainingNow() {
    final endsAt = _endsAt;
    if (endsAt == null) return state.remainingSeconds;
    final ms = endsAt.difference(AppClock.now()).inMilliseconds;
    return math.max(0, (ms / 1000).ceil());
  }

  void _tick() {
    final remaining = _remainingNow();
    if (remaining <= 0) {
      unawaited(_complete());
    } else if (remaining != state.remainingSeconds) {
      state = state.copyWith(remainingSeconds: remaining);
    }
  }

  Future<void> _complete({bool showNotification = true}) async {
    if (state.status == FocusTimerStatus.saving) return;
    _ticker?.cancel();
    final minutes = state.selectedMinutes;
    final projectId = state.projectId;
    final startedAt =
        _sessionStart ?? AppClock.now().subtract(Duration(minutes: minutes));
    final sessionId = _sessionId ?? _uuid.v4();
    _sessionId = sessionId;
    _endsAt = null;

    // Stay visibly unfinished until the row is committed. The alert is played
    // only after that, so a failed write cannot look like a saved session.
    state = state.copyWith(
      status: FocusTimerStatus.saving,
      remainingSeconds: 0,
      clearRecoveryNotice: true,
    );

    try {
      await ref
          .read(focusRepositoryProvider)
          .completeSession(
            sessionId: sessionId,
            durationMinutes: minutes,
            projectId: projectId,
            startedAt: startedAt,
            notify: showNotification,
          );
      if (_disposed) return;
      await _clearPendingIfSame(sessionId);
      await _clearPersistedState();
      if (showNotification) {
        SystemSound.play(SystemSoundType.alert).catchError((Object _) {});
      }
      _sessionStart = null;
      _sessionId = null;
      state = state.copyWith(
        status: FocusTimerStatus.idle,
        remainingSeconds: minutes * 60,
        completedCount: state.completedCount + 1,
        lastCompletedMinutes: minutes,
        clearRecoveryNotice: true,
      );
    } catch (e, st) {
      debugPrint('Failed to save focus session: $e\n$st');
      var persisted = false;
      try {
        await _persistPendingCompletion(
          sessionId: sessionId,
          durationMinutes: minutes,
          projectId: projectId,
          startedAt: startedAt,
        );
        await _clearPersistedState();
        persisted = true;
      } catch (persistError, persistStack) {
        debugPrint(
          'Failed to persist focus-session recovery state: '
          '$persistError\n$persistStack',
        );
      }
      if (_disposed) return;
      state = state.copyWith(
        status: FocusTimerStatus.saveFailed,
        remainingSeconds: 0,
        recoveryNotice: persisted
            ? 'This focus session finished but could not be saved ($e). '
                  'It is queued for the next launch. Retry to save it now.'
            : 'This focus session finished but could not be saved, and the '
                  'recovery record could not be written ($e).',
      );
    }
  }

  Future<void> retrySave() => _complete();

  Future<void> _clearPendingIfSame(String sessionId) async {
    if (_disposed) return;
    final db = ref.read(databaseProvider);
    final raw = await db.getSetting(_pendingCompletionKey);
    if (raw == null) return;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map && decoded['sessionId'] == sessionId) {
        await db.deleteSetting(_pendingCompletionKey);
      }
    } catch (_) {
      // A corrupt pending record is not this session; leave it for startup.
    }
  }

  /// Waits for persisted timer state to finish restoring. Test hook only.
  @visibleForTesting
  Future<void> debugWaitForRestore() => _restoreFuture;

  /// Finishes the current session immediately. Test hook only.
  @visibleForTesting
  Future<void> debugComplete() => _complete();
}

final focusTimerProvider =
    NotifierProvider<FocusTimerNotifier, FocusTimerState>(
      FocusTimerNotifier.new,
    );
