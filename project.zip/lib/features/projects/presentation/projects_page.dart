import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';

import '../../../core/domain/project_model.dart';
import '../../../core/db/app_database.dart';
import '../../../core/widgets/undo_snackbar.dart';
import '../../../core/providers/clock_provider.dart';
import '../../../core/providers/database_provider.dart';
import '../../../core/providers/service_providers.dart';
import '../../../core/utils/app_clock.dart';
import '../../../core/utils/date_picker_range.dart';
import '../../../core/utils/day_math.dart';
import '../data/project_repository.dart';
import '../data/project_workflow_repository.dart';
import 'milestone_dialog.dart';
import 'project_task_dialog.dart';
import 'project_timeline.dart';
import 'status_settings_dialog.dart';
import '../../tasks/data/task_metadata.dart';
import '../../tasks/data/task_repository.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/hover_card.dart';
import '../../../core/widgets/user_action_error.dart';
import '../../../core/widgets/dispose_with.dart';

part 'projects_widgets.dart';

class ProjectsPage extends ConsumerStatefulWidget {
  const ProjectsPage({super.key});

  @override
  ConsumerState<ProjectsPage> createState() => _ProjectsPageState();
}

class _ProjectsPageState extends ConsumerState<ProjectsPage> {
  @override
  Widget build(BuildContext context) {
    final projectsAsync = ref.watch(projectsStreamProvider);
    final progressAsync = ref.watch(projectProgressStreamProvider);
    ref.watch(dayChangeProvider); // so "overdue" updates at midnight
    final today = ref.watch(clockProvider)();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Projects'),
        automaticallyImplyLeading: false,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: FilledButton.icon(
              onPressed: () => _showAddEditProjectDialog(),
              icon: const Icon(Icons.add),
              label: const Text('New project'),
            ),
          ),
        ],
      ),
      body: projectsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, _) => const Center(child: Text('Could not load projects.')),
        data: (projects) {
          if (projects.isEmpty) {
            return EmptyState(
              icon: Icons.folder_outlined,
              title: 'No projects yet',
              subtitle: 'Create a project to track progress and tasks.',
              buttonLabel: 'Create Project',
              onButtonPressed: () => _showAddEditProjectDialog(),
            );
          }

          return LayoutBuilder(
            builder: (context, constraints) {
              final columns = constraints.maxWidth >= 1280
                  ? 3
                  : constraints.maxWidth >= 760
                  ? 2
                  : 1;
              final horizontalPadding = constraints.maxWidth >= 900
                  ? 24.0
                  : 16.0;
              final gap = 16.0;
              final cardWidth =
                  (constraints.maxWidth -
                      horizontalPadding * 2 -
                      gap * (columns - 1)) /
                  columns;

              return GridView.builder(
                padding: EdgeInsets.fromLTRB(
                  horizontalPadding,
                  8,
                  horizontalPadding,
                  96,
                ),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: columns,
                  crossAxisSpacing: gap,
                  mainAxisSpacing: gap,
                  mainAxisExtent: cardWidth >= 360 ? 236 : 252,
                ),
                itemCount: projects.length,
                itemBuilder: (context, index) {
                  final project = projects[index];
                  final progress =
                      (progressAsync.valueOrNull?[project.id] ?? 0.0)
                          .clamp(0.0, 100.0)
                          .toDouble();
                  return _ProjectCard(
                    today: today,
                    project: project,
                    progress: progress,
                    onTap: () => _showProjectDetail(project),
                    onEdit: () =>
                        _showAddEditProjectDialog(existingProject: project),
                    onDelete: () => _deleteProject(project),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }

  // ==================== ADD / EDIT PROJECT ====================
  void _showAddEditProjectDialog({ProjectModel? existingProject}) {
    final isEditing = existingProject != null;

    final nameController = TextEditingController(
      text: existingProject?.name ?? '',
    );
    final descController = TextEditingController(
      text: existingProject?.description ?? '',
    );
    DateTime? targetDate = existingProject?.targetDate;
    var targetProgress = existingProject?.targetProgress ?? 100;

    showDialog(
      context: context,
      builder: (context) => DisposeWith(
        disposables: [nameController, descController],
        child: StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(isEditing ? 'Edit Project' : 'Create New Project'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        labelText: 'Project Name*',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: descController,
                      decoration: const InputDecoration(
                        labelText: 'Description (optional)',
                      ),
                      maxLines: 3,
                    ),
                    const SizedBox(height: 12),
                    ListTile(
                      title: Text(
                        targetDate == null
                            ? 'No target date set'
                            : 'Target Date: ${DateFormat('MMM dd, yyyy').format(targetDate!)}',
                      ),
                      trailing: const Icon(Icons.calendar_today),
                      onTap: () async {
                        // The range must contain the current value: an overdue
                        // project's target is before today.
                        final range = datePickerRange(
                          current: targetDate,
                          today: ref.read(clockProvider)(),
                        );
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: range.initial,
                          firstDate: range.first,
                          lastDate: range.last,
                        );
                        if (picked != null) {
                          setDialogState(() => targetDate = picked);
                        }
                      },
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Expanded(child: Text('Checklist target')),
                        Text('$targetProgress%'),
                      ],
                    ),
                    Slider(
                      value: targetProgress.clamp(0, 100).toDouble(),
                      min: 0,
                      max: 100,
                      divisions: 20,
                      label: '$targetProgress%',
                      onChanged: (value) =>
                          setDialogState(() => targetProgress = value.round()),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () async {
                    if (nameController.text.trim().isEmpty) return;

                    final repository = ref.read(projectRepositoryProvider);
                    final success = await runUserMutation(
                      context,
                      () async {
                        if (isEditing) {
                          await repository.update(
                            existingProject.copyWith(
                              name: nameController.text.trim(),
                              description: descController.text.trim().isEmpty
                                  ? null
                                  : descController.text.trim(),
                              targetDate: targetDate,
                              targetProgress: targetProgress,
                            ),
                          );
                        } else {
                          await repository.create(
                            name: nameController.text.trim(),
                            description: descController.text.trim().isEmpty
                                ? null
                                : descController.text.trim(),
                            targetDate: targetDate,
                            targetProgress: targetProgress,
                          );
                        }
                      },
                      failureMessage: isEditing
                          ? 'Could not save the project.'
                          : 'Could not create the project.',
                    );

                    if (!success || !context.mounted) return;
                    Navigator.pop(context);
                  },
                  child: Text(isEditing ? 'Update' : 'Create Project'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  // ==================== DELETE PROJECT ====================
  Future<void> _deleteProject(ProjectModel project) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Project?'),
        content: Text(
          'Delete "${project.name}", its checklist, and its progress journal?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      if (!mounted) return;
      final success = await runUserMutation(
        context,
        () => ref.read(projectRepositoryProvider).deleteWithUndo(project.id),
        failureMessage: 'Could not delete the project.',
      );
      if (success && mounted) {
        UndoSnackbar.show(
          context,
          message: 'Project deleted',
          service: ref.read(undoServiceProvider),
        );
      }
    }
  }

  // ==================== PROJECT DETAIL SHEET ====================
  void _showProjectDetail(ProjectModel project) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.85,
          minChildSize: 0.5,
          maxChildSize: 0.95,
          expand: false,
          builder: (context, scrollController) {
            return SingleChildScrollView(
              controller: scrollController,
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          project.name,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  if (project.description != null &&
                      project.description!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Text(project.description!),
                    ),

                  // ==================== TASKS SECTION ====================
                  const Text(
                    'Checklist',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'The completion percentage is finished checklist items, measured against the target.',
                    style: TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  _TasksSection(projectId: project.id),

                  const SizedBox(height: 24),

                  // ==================== MILESTONES ====================
                  const Text(
                    'Milestones',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Project checkpoints, separate from checklist tasks.',
                    style: TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  _MilestonesSection(projectId: project.id),

                  const SizedBox(height: 24),

                  // ==================== LINKED TO-DOS ====================
                  const Text(
                    'Linked to-dos',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Standalone to-dos assigned to this project from the To-do page.',
                    style: TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  _LinkedTodosSection(projectId: project.id),

                  const SizedBox(height: 24),

                  // ==================== LOG PROGRESS SECTION ====================
                  const Text(
                    'Progress journal',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  _ProgressLogSection(projectId: project.id),

                  const SizedBox(height: 24),

                  // ==================== PROGRESS HISTORY ====================
                  const Text(
                    'Journal history',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  _ProgressHistorySection(projectId: project.id),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

/// Read-only view of standalone to-dos linked to this project. Linking and
/// un-linking happens in the To-do editor; this section makes the association
/// visible where the project is reviewed.
class _LinkedTodosSection extends ConsumerWidget {
  const _LinkedTodosSection({required this.projectId});

  final String projectId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tasks = ref.watch(tasksStreamProvider);
    return tasks.when(
      loading: () => const LinearProgressIndicator(),
      error: (_, _) => const Text('Could not load linked to-dos.'),
      data: (items) {
        final linked =
            items.where((task) => task.projectId == projectId).toList()
              ..sort((a, b) {
                if (a.completed != b.completed) return a.completed ? 1 : -1;
                return a.title.toLowerCase().compareTo(b.title.toLowerCase());
              });
        if (linked.isEmpty) {
          return const Text(
            'No to-dos are linked to this project yet. Link one from the '
            'To-do page.',
            style: TextStyle(color: Colors.grey),
          );
        }
        return Card(
          child: Column(
            children: [
              for (var i = 0; i < linked.length; i++) ...[
                if (i > 0) const Divider(height: 1),
                CheckboxListTile(
                  value: linked[i].completed,
                  title: Text(linked[i].title),
                  subtitle: linked[i].dueDate == null
                      ? null
                      : Text(
                          'Due ${DateFormat('MMM dd, yyyy').format(linked[i].dueDate!)}',
                        ),
                  onChanged: (value) async {
                    await runUserMutation(
                      context,
                      () => ref
                          .read(taskRepositoryProvider)
                          .toggle(linked[i].id, value ?? false),
                      failureMessage: 'Could not update the linked to-do.',
                    );
                  },
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}
