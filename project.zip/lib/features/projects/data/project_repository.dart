import 'package:drift/drift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../../../core/db/app_database.dart';
import '../../../core/domain/project_model.dart';
import '../../../core/domain/project_status.dart';
import '../../../core/providers/database_provider.dart';
import '../../../core/providers/service_providers.dart';
import '../../../core/services/undo_service.dart';
import 'project_mapper.dart';
import '../../../core/utils/app_clock.dart';

final projectRepositoryProvider = Provider<ProjectRepository>((ref) {
  return ProjectRepository(
    ref.watch(databaseProvider),
    ref.watch(undoServiceProvider),
  );
});

final projectsStreamProvider = StreamProvider<List<ProjectModel>>((ref) {
  return ref.watch(projectRepositoryProvider).watchAll();
});

final projectProgressStreamProvider = StreamProvider<Map<String, double>>((
  ref,
) {
  return ref.watch(databaseProvider).watchProjectProgress();
});

final projectTasksProvider = StreamProvider.autoDispose
    .family<List<Task>, String>((ref, projectId) {
      return ref.watch(projectRepositoryProvider).watchTasks(projectId);
    });

final projectProgressLogsProvider = StreamProvider.autoDispose
    .family<List<ProgressLog>, String>((ref, projectId) {
      return ref.watch(projectRepositoryProvider).watchProgress(projectId);
    });

class ProjectRepository {
  ProjectRepository(this._db, this._undo);
  final AppDatabase _db;
  final UndoService _undo;
  final _uuid = const Uuid();

  Stream<List<ProjectModel>> watchAll() => _db.watchProjects().map(
    (projects) => projects.map(projectModelFromDrift).toList(growable: false),
  );
  Stream<List<ProgressLog>> watchProgress(String projectId) =>
      _db.watchProgressForProject(projectId);
  Stream<List<Task>> watchTasks(String projectId) =>
      _db.watchTasksForProject(projectId);

  Future<void> create({
    required String name,
    String? description,
    DateTime? targetDate,
    int targetProgress = 100,
  }) async {
    if (targetProgress < 0 || targetProgress > 100) {
      throw ArgumentError.value(
        targetProgress,
        'targetProgress',
        'must be between 0 and 100',
      );
    }
    final id = _uuid.v4();
    await _db.transaction(() async {
      await _db
          .into(_db.projects)
          .insert(
            ProjectsCompanion(
              id: Value(id),
              name: Value(name),
              description: Value(description),
              createdAt: Value(AppClock.now()),
              targetDate: Value(targetDate),
              targetProgress: Value(targetProgress),
            ),
          );
      await _db.ensureProjectStatuses(id);
    });
  }

  Future<void> update(ProjectModel project) async {
    if (project.targetProgress < 0 || project.targetProgress > 100) {
      throw ArgumentError.value(
        project.targetProgress,
        'project.targetProgress',
        'must be between 0 and 100',
      );
    }
    await (_db.update(
      _db.projects,
    )..where((t) => t.id.equals(project.id))).write(
      ProjectsCompanion(
        name: Value(project.name),
        description: Value(project.description),
        targetDate: Value(project.targetDate),
        targetProgress: Value(project.targetProgress),
      ),
    );
  }

  Future<void> delete(String id) async {
    await _db.deleteProject(id);
  }

  Future<void> deleteWithUndo(String id) async {
    final project = await (_db.select(
      _db.projects,
    )..where((t) => t.id.equals(id))).getSingleOrNull();
    if (project == null) return;
    final tasks = await (_db.select(
      _db.tasks,
    )..where((t) => t.projectId.equals(id))).get();
    final taskIds = tasks.map((task) => task.id).toSet();
    final statuses = await (_db.select(
      _db.projectStatuses,
    )..where((t) => t.projectId.equals(id))).get();
    final milestones = await (_db.select(
      _db.projectMilestones,
    )..where((t) => t.projectId.equals(id))).get();
    final dependencies = await _db.select(_db.taskDependencies).get();
    final projectDependencies = dependencies
        .where(
          (dependency) =>
              taskIds.contains(dependency.predecessorTaskId) ||
              taskIds.contains(dependency.successorTaskId),
        )
        .toList();
    final logs = await (_db.select(
      _db.progressLogs,
    )..where((t) => t.projectId.equals(id))).get();
    final sessions = await (_db.select(
      _db.focusSessions,
    )..where((t) => t.projectId.equals(id))).get();

    await _db.deleteProject(id);
    _undo.offer(
      label: 'project',
      restore: () async {
        await _db.transaction(() async {
          await _db.into(_db.projects).insert(project);
          for (final status in statuses) {
            await _db.into(_db.projectStatuses).insertOnConflictUpdate(status);
          }
          for (final milestone in milestones) {
            await _db
                .into(_db.projectMilestones)
                .insertOnConflictUpdate(milestone);
          }
          for (final task in tasks) {
            await _db.into(_db.tasks).insert(task);
          }
          for (final dependency in projectDependencies) {
            await _db
                .into(_db.taskDependencies)
                .insertOnConflictUpdate(dependency);
          }
          for (final log in logs) {
            await _db.into(_db.progressLogs).insert(log);
          }
          for (final session in sessions) {
            await (_db.update(_db.focusSessions)
                  ..where((t) => t.id.equals(session.id)))
                .write(FocusSessionsCompanion(projectId: Value(id)));
          }
        });
      },
    );
  }

  Future<void> logProgress({
    required String projectId,
    required int value,
    String? note,
  }) async {
    if (value < 0 || value > 100) {
      throw ArgumentError.value(value, 'value', 'must be between 0 and 100');
    }
    await _db
        .into(_db.progressLogs)
        .insert(
          ProgressLogsCompanion(
            id: Value(_uuid.v4()),
            projectId: Value(projectId),
            value: Value(value),
            note: Value(note),
            timestamp: Value(AppClock.now()),
          ),
        );
  }

  Future<double> progressPercent(String projectId) =>
      _db.projectProgressPercent(projectId);

  Future<void> addTask({
    required String projectId,
    required String title,
  }) async {
    await _db.addTask(projectId, title);
  }

  Future<void> toggleTask(Task task, bool completed) async {
    final statusKey = completed
        ? ProjectStatusCatalog.done.key
        : ProjectStatusCatalog.isDoneKey(task.statusKey)
        ? ProjectStatusCatalog.todo.key
        : task.statusKey;
    await (_db.update(_db.tasks)..where((t) => t.id.equals(task.id))).write(
      TasksCompanion(statusKey: Value(statusKey), completed: Value(completed)),
    );
  }

  Future<void> deleteTask(String id) async {
    await (_db.delete(_db.tasks)..where((t) => t.id.equals(id))).go();
  }
}
