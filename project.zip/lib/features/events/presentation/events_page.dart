import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' as drift;
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';

import '../../../core/db/app_database.dart';
import '../../../core/providers/clock_provider.dart';
import '../../../core/providers/service_providers.dart';
import '../../../core/widgets/attachment_strip.dart';
import '../../../core/widgets/notes_field.dart';
import '../../../core/widgets/undo_snackbar.dart';
import '../../../core/widgets/user_action_error.dart';
import '../../../core/widgets/dispose_with.dart';
import '../../../core/utils/recurrence.dart';
import '../../../core/utils/md1_plain.dart';
import '../../../core/utils/date_picker_range.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/providers/command_action_provider.dart';
import '../data/event_repository.dart';
import '../../../core/utils/app_clock.dart';

class EventsPage extends ConsumerStatefulWidget {
  const EventsPage({super.key});

  @override
  ConsumerState<EventsPage> createState() => _EventsPageState();
}

class _EventsPageState extends ConsumerState<EventsPage> {
  late DateTime _focusedDay;
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _focusedDay = ref.read(clockProvider)();
    _selectedDay = _focusedDay;
    // See the note in tasks_page.dart: the palette sets the action before this
    // page exists, so pick it up once on first build.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (ref.read(commandActionProvider) == CommandAction.newEvent) {
        ref.read(commandActionProvider.notifier).clear();
        _showEventDialog();
      }
    });
  }

  // Show Add or Edit Dialog
  void _showEventDialog({Event? existingEvent}) {
    final isEditing = existingEvent != null;

    final titleController = TextEditingController(
      text: existingEvent?.title ?? '',
    );
    final descController = TextEditingController(
      text: existingEvent?.description ?? '',
    );
    String selectedCategory = existingEvent?.category ?? 'general';
    var descriptionFormat = existingEvent?.descriptionFormat ?? 'plain';
    // Offered in the dropdown even if it isn't one of ours, so editing an
    // imported event doesn't silently change its category.
    final originalCategory = selectedCategory;
    DateTime selectedDate = existingEvent?.startTime ?? AppClock.now();
    TimeOfDay selectedTime = TimeOfDay.fromDateTime(
      existingEvent?.startTime ?? AppClock.now(),
    );
    bool hasReminder = existingEvent?.hasReminder ?? false;
    int reminderMinutes = existingEvent?.reminderMinutes ?? 10;
    String recurrenceRule = existingEvent?.recurrenceRule ?? Recurrence.none;
    bool allDay = existingEvent?.allDay ?? false;

    showDialog(
      context: context,
      builder: (context) => DisposeWith(
        disposables: [titleController, descController],
        child: StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(isEditing ? 'Edit Event' : 'Add New Event'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: titleController,
                      decoration: const InputDecoration(
                        labelText: 'Event Title*',
                      ),
                    ),
                    const SizedBox(height: 12),
                    NotesField(
                      controller: descController,
                      format: descriptionFormat,
                      onFormatChanged: (value) =>
                          setDialogState(() => descriptionFormat = value),
                      label: 'Description (optional)',
                      hint: 'Agenda, location, links…',
                      minLines: 2,
                      maxLines: 5,
                      imageResolver: (id) async {
                        final service = await ref.read(
                          attachmentServiceProvider.future,
                        );
                        return service.thumbnailById(id);
                      },
                    ),
                    const SizedBox(height: 12),

                    // Category Dropdown
                    DropdownButtonFormField<String>(
                      initialValue: selectedCategory,
                      items: EventCategories.optionsFor(originalCategory)
                          .map(
                            (category) => DropdownMenuItem<String>(
                              value: category.$1,
                              child: Text(category.$2),
                            ),
                          )
                          .toList(),
                      onChanged: (val) =>
                          setDialogState(() => selectedCategory = val!),
                      decoration: const InputDecoration(labelText: 'Category'),
                    ),
                    const SizedBox(height: 12),

                    // Date Picker
                    ListTile(
                      title: Text(
                        'Date: ${DateFormat('MMM dd, yyyy').format(selectedDate)}',
                      ),
                      trailing: const Icon(Icons.calendar_today),
                      onTap: () async {
                        final range = datePickerRange(
                          current: selectedDate,
                          today: ref.read(clockProvider)(),
                          lastYear: 2030,
                          earliest: DateTime(2020),
                        );
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: range.initial,
                          firstDate: range.first,
                          lastDate: range.last,
                        );
                        if (picked != null) {
                          setDialogState(() => selectedDate = picked);
                        }
                      },
                    ),

                    // Time Picker
                    if (!allDay)
                      ListTile(
                        title: Text('Time: ${selectedTime.format(context)}'),
                        trailing: const Icon(Icons.access_time),
                        onTap: () async {
                          final picked = await showTimePicker(
                            context: context,
                            initialTime: selectedTime,
                          );
                          if (picked != null) {
                            setDialogState(() => selectedTime = picked);
                          }
                        },
                      ),
                    SwitchListTile(
                      title: const Text('All day'),
                      subtitle: const Text(
                        'Date-only event. Reminders are turned off.',
                      ),
                      value: allDay,
                      onChanged: (value) => setDialogState(() {
                        allDay = value;
                        if (value) hasReminder = false;
                      }),
                    ),

                    const SizedBox(height: 8),
                    if (!allDay)
                      CheckboxListTile(
                        title: const Text('Set Reminder'),
                        subtitle: const Text(
                          'Delivered while Locus is open. If it is closed, the '
                          'reminder is listed in Today\'s missed reminders.',
                        ),
                        value: hasReminder,
                        onChanged: (val) =>
                            setDialogState(() => hasReminder = val!),
                      ),

                    if (!allDay && hasReminder)
                      DropdownButtonFormField<int>(
                        initialValue: reminderMinutes,
                        items: const [5, 10, 15, 30, 60]
                            .map(
                              (m) => DropdownMenuItem(
                                value: m,
                                child: Text('$m minutes before'),
                              ),
                            )
                            .toList(),
                        onChanged: (val) =>
                            setDialogState(() => reminderMinutes = val!),
                        decoration: const InputDecoration(
                          labelText: 'Reminder Time',
                        ),
                      ),

                    const SizedBox(height: 12),
                    AttachmentStrip(eventId: existingEvent?.id),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      initialValue: recurrenceRule,
                      items: Recurrence.values
                          .map(
                            (rule) => DropdownMenuItem(
                              value: rule,
                              child: Text(Recurrence.label(rule)),
                            ),
                          )
                          .toList(),
                      onChanged: (val) => setDialogState(
                        () => recurrenceRule = val ?? Recurrence.none,
                      ),
                      decoration: const InputDecoration(labelText: 'Repeat'),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () async {
                    if (titleController.text.trim().isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Title cannot be empty')),
                      );
                      return;
                    }

                    final eventDateTime = DateTime(
                      selectedDate.year,
                      selectedDate.month,
                      selectedDate.day,
                      allDay ? 0 : selectedTime.hour,
                      allDay ? 0 : selectedTime.minute,
                    );

                    final repo = ref.read(eventRepositoryProvider);
                    final rule = recurrenceRule == Recurrence.none
                        ? null
                        : recurrenceRule;
                    final description = descController.text.trim();
                    final success = await runUserMutation(
                      context,
                      () async {
                        if (isEditing) {
                          await repo.update(
                            existingEvent.copyWith(
                              title: titleController.text.trim(),
                              description: drift.Value(
                                description.isEmpty ? null : description,
                              ),
                              descriptionFormat: description.isEmpty
                                  ? 'plain'
                                  : descriptionFormat,
                              startTime: eventDateTime,
                              category: selectedCategory,
                              hasReminder: hasReminder,
                              reminderMinutes: reminderMinutes,
                              recurrenceRule: drift.Value(rule),
                              allDay: allDay,
                            ),
                          );
                        } else {
                          await repo.create(
                            title: titleController.text.trim(),
                            description: description.isEmpty
                                ? null
                                : description,
                            descriptionFormat: description.isEmpty
                                ? 'plain'
                                : descriptionFormat,
                            startTime: eventDateTime,
                            category: selectedCategory,
                            hasReminder: hasReminder,
                            reminderMinutes: reminderMinutes,
                            recurrenceRule: rule,
                            allDay: allDay,
                          );
                        }
                      },
                      failureMessage: isEditing
                          ? 'Could not save the event.'
                          : 'Could not add the event.',
                    );

                    if (!success || !context.mounted) return;
                    Navigator.pop(context);
                  },
                  child: Text(isEditing ? 'Update Event' : 'Add Event'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Future<void> _deleteEvent(Event event) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Event?'),
        content: Text('Are you sure you want to delete "${event.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      if (!mounted) return;
      final success = await runUserMutation(
        context,
        () => ref.read(eventRepositoryProvider).deleteWithUndo(event.id),
        failureMessage: 'Could not delete the event.',
      );
      if (!success || !mounted) return;
      UndoSnackbar.show(
        context,
        message: 'Event deleted',
        service: ref.read(undoServiceProvider),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final selectedDay = _selectedDay ?? _focusedDay;
    final attachmentCounts =
        ref.watch(attachmentCountsProvider).valueOrNull?.events ??
        const <String, int>{};
    final markerMonth = DateTime(_focusedDay.year, _focusedDay.month, 1);
    final markerMap =
        ref.watch(eventMarkersProvider(markerMonth)).valueOrNull ??
        const <DateTime, List<Event>>{};

    // Listen for command palette action
    ref.listen<CommandAction>(commandActionProvider, (previous, next) {
      if (next == CommandAction.newEvent) {
        // Reset the action
        ref.read(commandActionProvider.notifier).clear();
        // Call your existing add event method
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _showEventDialog(); // ← use the name of your add/edit dialog method
        });
      }
    });

    return Scaffold(
      appBar: AppBar(
        title: const Text('Events'),
        automaticallyImplyLeading: false,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showEventDialog(),
        child: const Icon(Icons.add),
      ),
      body: Column(
        children: [
          // Calendar
          TableCalendar<Event>(
            firstDay: DateTime.utc(2020, 1, 1),
            lastDay: DateTime.utc(2030, 12, 31),
            focusedDay: _focusedDay,
            selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
            eventLoader: (day) =>
                markerMap[DateTime(day.year, day.month, day.day)] ??
                const <Event>[],
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay = focusedDay;
              });
            },
            onPageChanged: (focusedDay) {
              setState(() => _focusedDay = focusedDay);
            },
            calendarStyle: const CalendarStyle(
              markersMaxCount: 3,
              markerDecoration: BoxDecoration(
                color: Color(0xFF6C5CE7),
                shape: BoxShape.circle,
              ),
            ),
          ),

          const Divider(height: 1),

          // Events List for Selected Day
          Expanded(
            child: ref
                .watch(selectedDayEventsProvider(selectedDay))
                .when(
                  loading: () =>
                      const Center(child: CircularProgressIndicator()),
                  error: (_, _) =>
                      const Center(child: Text('Could not load events.')),
                  data: (events) {
                    if (events.isEmpty) {
                      return const Center(
                        child: Text(
                          'No events on this day.\nTap + to add one.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.grey),
                        ),
                      );
                    }

                    return ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: events.length,
                      itemBuilder: (context, index) {
                        final occurrence = events[index];
                        final event = occurrence.event;
                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor: const Color(
                                0xFF6C5CE7,
                              ).withValues(alpha: 0.1),
                              child: const Icon(
                                Icons.event,
                                color: Color(0xFF6C5CE7),
                              ),
                            ),
                            title: Text(
                              event.title,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  event.allDay
                                      ? 'All day • ${event.category}'
                                      : '${DateFormat('hh:mm a').format(occurrence.start)} • ${event.category}',
                                ),
                                if (event.description != null &&
                                    event.description!.isNotEmpty)
                                  Text(
                                    event.descriptionFormat == 'md1'
                                        ? plainTextFromMd1(
                                            event.description!,
                                            maxChars: 120,
                                          )
                                        : event.description!,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                              ],
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (Recurrence.isRecurring(
                                  event.recurrenceRule,
                                ))
                                  const Icon(
                                    Icons.repeat,
                                    color: Colors.blue,
                                    size: 20,
                                  ),
                                if (event.hasReminder)
                                  const Icon(
                                    Icons.notifications_active,
                                    color: Colors.orange,
                                    size: 20,
                                  ),
                                if ((attachmentCounts[event.id] ?? 0) > 0)
                                  Semantics(
                                    label:
                                        '${attachmentCounts[event.id]} '
                                        'attachment'
                                        '${attachmentCounts[event.id] == 1 ? '' : 's'}',
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 6),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          const Icon(
                                            Icons.attach_file,
                                            size: 18,
                                            color: Colors.grey,
                                          ),
                                          Text(
                                            '${attachmentCounts[event.id]}',
                                            style: const TextStyle(
                                              fontSize: 12,
                                              color: Colors.grey,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                IconButton(
                                  tooltip: 'Edit event',
                                  icon: const Icon(Icons.edit, size: 20),
                                  onPressed: () =>
                                      _showEventDialog(existingEvent: event),
                                ),
                                IconButton(
                                  tooltip: 'Delete event',
                                  icon: const Icon(
                                    Icons.delete,
                                    color: Colors.red,
                                    size: 20,
                                  ),
                                  onPressed: () => _deleteEvent(event),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
          ),
        ],
      ),
    );
  }
}
