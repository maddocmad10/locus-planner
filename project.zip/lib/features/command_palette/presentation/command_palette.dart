import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../core/db/app_database.dart';
import '../../../core/domain/project_model.dart';
import '../../../core/providers/command_action_provider.dart';
import '../../focus/providers/focus_timer_provider.dart';
import '../providers/command_palette_provider.dart';

class CommandPalette extends ConsumerStatefulWidget {
  final Function(int) onNavigate;

  const CommandPalette({super.key, required this.onNavigate});

  @override
  ConsumerState<CommandPalette> createState() => _CommandPaletteState();
}

class _CommandPaletteState extends ConsumerState<CommandPalette> {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  String _query = '';
  int _selectedIndex = 0;

  late final List<_CommandItem> _staticCommands;

  @override
  void initState() {
    super.initState();

    _staticCommands = [
      // Navigation
      _CommandItem(
        title: 'Go to Today',
        subtitle: 'Dashboard',
        icon: Icons.dashboard_outlined,
        category: 'Navigation',
        action: () => widget.onNavigate(0),
      ),
      _CommandItem(
        title: 'Go to Events',
        subtitle: 'Calendar & reminders',
        icon: Icons.event_outlined,
        category: 'Navigation',
        action: () => widget.onNavigate(1),
      ),
      _CommandItem(
        title: 'Go to Projects',
        subtitle: 'Projects & progress',
        icon: Icons.folder_outlined,
        category: 'Navigation',
        action: () => widget.onNavigate(2),
      ),
      _CommandItem(
        title: 'Go to Tasks',
        subtitle: 'To-do list',
        icon: Icons.checklist_outlined,
        category: 'Navigation',
        action: () => widget.onNavigate(3),
      ),
      _CommandItem(
        title: 'Go to Habits',
        subtitle: 'Habits & heatmap',
        icon: Icons.check_circle_outlined,
        category: 'Navigation',
        action: () => widget.onNavigate(4),
      ),
      _CommandItem(
        title: 'Go to Focus',
        subtitle: 'Focus timer',
        icon: Icons.timer_outlined,
        category: 'Navigation',
        action: () => widget.onNavigate(5),
      ),
      _CommandItem(
        title: 'Go to Diary',
        subtitle: 'Daily journal',
        icon: Icons.book_outlined,
        category: 'Navigation',
        action: () => widget.onNavigate(6),
      ),
      _CommandItem(
        title: 'Go to Insights',
        subtitle: 'Charts & stats',
        icon: Icons.insights_outlined,
        category: 'Navigation',
        action: () => widget.onNavigate(7),
      ),
      _CommandItem(
        title: 'Go to Settings',
        subtitle: 'Theme, export, import',
        icon: Icons.settings_outlined,
        category: 'Navigation',
        action: () => widget.onNavigate(8),
      ),

      // Actions
      _CommandItem(
        title: 'New Event',
        subtitle: 'Create a new event',
        icon: Icons.event,
        category: 'Actions',
        action: () {
          widget.onNavigate(1);
          ref
              .read(commandActionProvider.notifier)
              .dispatch(CommandAction.newEvent);
        },
      ),
      _CommandItem(
        title: 'New Task',
        subtitle: 'Add a to-do item',
        icon: Icons.add_task,
        category: 'Actions',
        action: () {
          widget.onNavigate(3);
          ref
              .read(commandActionProvider.notifier)
              .dispatch(CommandAction.newTask);
        },
      ),
      _CommandItem(
        title: 'New Habit',
        subtitle: 'Create a new habit',
        icon: Icons.add_circle_outline,
        category: 'Actions',
        action: () {
          widget.onNavigate(4);
          ref
              .read(commandActionProvider.notifier)
              .dispatch(CommandAction.newHabit);
        },
      ),
      _CommandItem(
        title: 'Start Focus Session',
        subtitle: 'Begin a focus timer',
        icon: Icons.play_arrow_rounded,
        category: 'Actions',
        action: () {
          ref.read(focusTimerProvider.notifier).start();
          widget.onNavigate(5);
        },
      ),
    ];

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  List<_CommandItem> _buildResults({
    required List<Event> events,
    required List<TodoItem> tasks,
    required List<Habit> habits,
    required List<ProjectModel> projects,
    required List<DiaryEntry> diaryEntries,
    required List<FocusSession> focusSessions,
  }) {
    final q = _query.trim().toLowerCase();
    final results = <_CommandItem>[];

    // 1. Static commands (always filtered)
    results.addAll(
      _staticCommands.where((c) {
        if (q.isEmpty) return true;
        return c.title.toLowerCase().contains(q) ||
            (c.subtitle?.toLowerCase().contains(q) ?? false) ||
            c.category.toLowerCase().contains(q);
      }),
    );

    if (q.isEmpty) return results;

    // The database already matched every section with a single case rule
    // (SQLite LIKE). Re-filtering here with Dart's toLowerCase would apply a
    // second, different Unicode case rule — silently dropping rows the DB
    // matched (e.g. a dotted 'İ' lowercases to 'i' + combining dot, which
    // does not contain a plain 'i') and shrinking the DB's LIMIT-ed results.
    // Render what the database returned.
    for (final event in events) {
      results.add(
        _CommandItem(
          title: event.title,
          subtitle: DateFormat('MMM d, h:mm a').format(event.startTime),
          icon: Icons.event,
          category: 'Event',
          action: () => widget.onNavigate(1),
        ),
      );
    }

    // 3. Tasks
    for (final task in tasks) {
      results.add(
        _CommandItem(
          title: task.title,
          subtitle: task.completed ? 'Completed' : 'Pending',
          icon: Icons.check_box_outlined,
          category: 'Task',
          action: () => widget.onNavigate(3),
        ),
      );
    }

    // 4. Habits
    for (final habit in habits) {
      results.add(
        _CommandItem(
          title: '${habit.icon} ${habit.name}',
          subtitle: 'Habit',
          icon: Icons.check_circle_outline,
          category: 'Habit',
          action: () => widget.onNavigate(4),
        ),
      );
    }

    // 5. Projects
    for (final project in projects) {
      results.add(
        _CommandItem(
          title: project.name,
          subtitle: 'Project',
          icon: Icons.folder_outlined,
          category: 'Project',
          action: () => widget.onNavigate(2),
        ),
      );
    }

    // 6. Diary
    for (final entry in diaryEntries) {
      results.add(
        _CommandItem(
          title: DateFormat('MMM d, yyyy').format(entry.date),
          subtitle: entry.content.replaceAll(RegExp(r'\s+'), ' ').trim(),
          icon: Icons.book_outlined,
          category: 'Diary',
          action: () => widget.onNavigate(6),
        ),
      );
    }

    // 7. Focus History
    for (final session in focusSessions) {
      results.add(
        _CommandItem(
          title: '${session.durationMinutes} minute focus session',
          subtitle: DateFormat(
            'MMM d, yyyy h:mm a',
          ).format(session.startTime),
          icon: Icons.timer_outlined,
          category: 'Focus',
          action: () => widget.onNavigate(5),
        ),
      );
    }

    return results;
  }

  KeyEventResult _onKey(KeyEvent event, List<_CommandItem> items) {
    if (event is! KeyDownEvent && event is! KeyRepeatEvent) {
      return KeyEventResult.ignored;
    }
    if (items.isEmpty) return KeyEventResult.ignored;
    if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
      setState(
        () => _selectedIndex = (_selectedIndex + 1).clamp(0, items.length - 1),
      );
      return KeyEventResult.handled;
    }
    if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
      setState(
        () => _selectedIndex = (_selectedIndex - 1).clamp(0, items.length - 1),
      );
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  void _runSelected(List<_CommandItem> items) {
    if (items.isEmpty) return;
    final index = _selectedIndex.clamp(0, items.length - 1);
    items[index].action();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 560, maxHeight: 520),
        child: Consumer(
          builder: (context, ref, _) {
            final search = ref.watch(commandSearchProvider(_query));
            final data = search.valueOrNull;
            final items = _buildResults(
              events: data?.events ?? const <Event>[],
              tasks: data?.tasks ?? const <TodoItem>[],
              habits: data?.habits ?? const <Habit>[],
              projects: data?.projects ?? const <ProjectModel>[],
              diaryEntries: data?.diaryEntries ?? const <DiaryEntry>[],
              focusSessions: data?.focusSessions ?? const <FocusSession>[],
            );

            if (search.isLoading && _query.trim().isNotEmpty && items.isEmpty) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(40),
                  child: CircularProgressIndicator(),
                ),
              );
            }

            if (_selectedIndex >= items.length) {
              _selectedIndex = items.isEmpty ? 0 : items.length - 1;
            }

            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Search field
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Focus(
                    onKeyEvent: (node, event) => _onKey(event, items),
                    child: TextField(
                      controller: _searchController,
                      focusNode: _focusNode,
                      decoration: InputDecoration(
                        hintText:
                            'Search commands, events, tasks, habits, diary...',
                        prefixIcon: const Icon(Icons.search),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                      ),
                      onChanged: (v) {
                        setState(() {
                          _query = v;
                          _selectedIndex = 0;
                        });
                      },
                      onSubmitted: (_) => _runSelected(items),
                    ),
                  ),
                ),

                const Divider(height: 1),

                // Results
                Flexible(
                  child: items.isEmpty
                      ? const Padding(
                          padding: EdgeInsets.all(40),
                          child: Text('No matching results'),
                        )
                      : ListView.builder(
                          shrinkWrap: true,
                          itemCount: items.length,
                          itemBuilder: (context, index) {
                            final cmd = items[index];
                            final isSelected = index == _selectedIndex;

                            return Material(
                              color: isSelected
                                  ? Theme.of(context).colorScheme.primary
                                        .withValues(alpha: 0.12)
                                  : Colors.transparent,
                              child: ListTile(
                                leading: Icon(
                                  cmd.icon,
                                  color: isSelected
                                      ? Theme.of(context).colorScheme.primary
                                      : null,
                                ),
                                title: Text(
                                  cmd.title,
                                  style: TextStyle(
                                    fontWeight: isSelected
                                        ? FontWeight.w600
                                        : FontWeight.normal,
                                  ),
                                ),
                                subtitle: cmd.subtitle != null
                                    ? Text(cmd.subtitle!)
                                    : null,
                                trailing: Text(
                                  cmd.category,
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                                onTap: () {
                                  cmd.action();
                                  Navigator.pop(context);
                                },
                              ),
                            );
                          },
                        ),
                ),

                // Footer
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest
                        .withValues(alpha: 0.4),
                    borderRadius: const BorderRadius.vertical(
                      bottom: Radius.circular(16),
                    ),
                  ),
                  child: Text(
                    '↑↓ Navigate  •  Enter Select  •  Esc Close',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _CommandItem {
  final String title;
  final String? subtitle;
  final IconData icon;
  final String category;
  final VoidCallback action;

  _CommandItem({
    required this.title,
    this.subtitle,
    required this.icon,
    required this.category,
    required this.action,
  });
}

Future<void> showCommandPalette(
  BuildContext context, {
  required Function(int) onNavigate,
}) {
  return showDialog(
    context: context,
    barrierDismissible: true,
    builder: (_) => CommandPalette(onNavigate: onNavigate),
  );
}
