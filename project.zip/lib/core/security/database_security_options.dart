import 'dart:io';

import '../config/build_config.dart';
import 'cipher_profile.dart';
import 'database_key_store.dart';

/// Process-wide configuration for the live-database encryption layer.
///
/// Encryption is **disabled by default** until the release gates pass. The
/// bundled SQLite3MC runtime is integrated and self-tested, but production
/// migration still waits for physical-device and recovery validation, so it
/// requires a separate migration switch.
class DatabaseSecurityOptions {
  const DatabaseSecurityOptions.plaintext({this.dataDirectory})
    : encryptLiveDatabase = false,
      allowAutomaticConversion = false,
      profile = CipherProfiles.active,
      keyStore = null,
      requireEncryptedAutomaticBackups = false;

  const DatabaseSecurityOptions.encrypted({
    this.profile = CipherProfiles.active,
    required this.keyStore,
    this.requireEncryptedAutomaticBackups = true,
    this.allowAutomaticConversion = false,
    this.dataDirectory,
  }) : encryptLiveDatabase = true;

  final bool encryptLiveDatabase;

  /// Whether an existing recognized plaintext database may be converted
  /// automatically at startup.
  ///
  /// Kept separate from [encryptLiveDatabase] so enabling the cipher in a build
  /// cannot silently migrate production data before the recovery gates pass.
  final bool allowAutomaticConversion;
  final CipherProfile profile;

  /// Required when [encryptLiveDatabase] is true.
  final DatabaseKeyStore? keyStore;

  /// Keep the backup policy fail-closed even if live encryption is temporarily
  /// disabled (for example during a migration rollback).
  final bool requireEncryptedAutomaticBackups;

  /// Test/portable override for the sensitive-state directory.
  final Directory? dataDirectory;
}

abstract final class DatabaseSecurity {
  static DatabaseSecurityOptions options =
      const DatabaseSecurityOptions.plaintext();

  /// Whether the database connection that is actually open uses encryption.
  /// A build can enable encryption for new installs while still opening an
  /// existing plaintext database unchanged.
  static bool? _runtimeEncryptionEnabled;

  static DatabaseSecurityOptions get current => options;

  static bool get liveEncryptionEnabled => options.encryptLiveDatabase;

  static bool get actualEncryptionEnabled =>
      _runtimeEncryptionEnabled ?? options.encryptLiveDatabase;

  static bool get backupsMustBeEncrypted {
    final runtime = _runtimeEncryptionEnabled;
    if (runtime != null) return runtime;
    return options.encryptLiveDatabase ||
        options.requireEncryptedAutomaticBackups;
  }

  static CipherProfile get profile => options.profile;

  static DatabaseKeyStore? get keyStore => options.keyStore;

  static void configure(DatabaseSecurityOptions value) {
    options = value;
    _runtimeEncryptionEnabled = null;
  }

  static void setRuntimeEncryption(bool enabled) {
    _runtimeEncryptionEnabled = enabled;
  }

  static void reset() {
    options = const DatabaseSecurityOptions.plaintext();
    _runtimeEncryptionEnabled = null;
  }

  /// Enables the layer from `LOCUS_DB_ENCRYPTION=1|true` or the compile-time
  /// `LOCUS_DB_ENCRYPTION` dart-define.
  ///
  /// `LOCUS_DB_MIGRATION=1|true` (or its dart-define) additionally permits
  /// automatic conversion of an existing plaintext database. Encryption can
  /// therefore be enabled in a build without silently migrating data.
  static void configureFromEnvironment({Map<String, String>? environment}) {
    final env = environment ?? Platform.environment;
    final flag = (env['LOCUS_DB_ENCRYPTION'] ?? '').toLowerCase();
    final migrationFlag = (env['LOCUS_DB_MIGRATION'] ?? '').toLowerCase();
    final enabled =
        BuildConfig.encryptDatabase || flag == '1' || flag == 'true';
    final migrationEnabled =
        BuildConfig.allowAutomaticDatabaseMigration ||
        migrationFlag == '1' ||
        migrationFlag == 'true';
    if (enabled) {
      configure(
        DatabaseSecurityOptions.encrypted(
          keyStore: createDefaultDatabaseKeyStore(),
          allowAutomaticConversion: migrationEnabled,
        ),
      );
    } else {
      reset();
    }
  }
}
