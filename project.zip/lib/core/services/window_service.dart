import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart' show Size, Offset, Rect;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:screen_retriever/screen_retriever.dart';
import 'package:window_manager/window_manager.dart';

import '../utils/window_placement.dart';

class WindowService with WindowListener {
  WindowService();

  static const _widthKey = 'window_width';
  static const _heightKey = 'window_height';
  static const _xKey = 'window_x';
  static const _yKey = 'window_y';
  static const _minimizeToTrayKey = 'minimize_to_tray';

  bool minimizeToTray = true;
  bool trayReady = false;

  /// Called when the window is actually closing (Exit, or close with
  /// minimize-to-tray disabled). Used to flush the database.
  Future<void> Function()? onExit;
  bool _closing = false;

  Future<void> init() async {
    windowManager.addListener(this);
    final prefs = await SharedPreferences.getInstance();
    minimizeToTray = prefs.getBool(_minimizeToTrayKey) ?? true;

    final width = prefs.getDouble(_widthKey) ?? 1360;
    final height = prefs.getDouble(_heightKey) ?? 860;
    final x = prefs.getDouble(_xKey);
    final y = prefs.getDouble(_yKey);

    await windowManager.setMinimumSize(const Size(900, 600));
    await windowManager.setSize(Size(width, height));
    if (x != null && y != null) {
      final position = await _safeRestorePosition(
        Offset(x, y),
        Size(width, height),
      );
      await windowManager.setPosition(position);
    }
  }

  Future<Offset> _safeRestorePosition(Offset saved, Size size) async {
    try {
      final displays = await screenRetriever.getAllDisplays();
      final primary = await screenRetriever.getPrimaryDisplay();
      return restoredWindowPosition(
        saved: saved,
        size: size,
        workAreas: [for (final display in displays) ?_workArea(display)],
        primaryWorkArea: _workArea(primary),
      );
    } catch (_) {
      // Display information only improves the restored position. If it isn't
      // available, opening the window where it was beats failing to start.
      return saved;
    }
  }

  Rect? _workArea(Display display) {
    final position = display.visiblePosition;
    final size = display.visibleSize;
    if (position == null || size == null) return null;
    return Rect.fromLTWH(position.dx, position.dy, size.width, size.height);
  }

  Timer? _saveBoundsTimer;

  Future<void> saveBounds() async {
    final bounds = await windowManager.getBounds();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_widthKey, bounds.width);
    await prefs.setDouble(_heightKey, bounds.height);
    await prefs.setDouble(_xKey, bounds.left);
    await prefs.setDouble(_yKey, bounds.top);
  }

  Future<void> _saveBoundsBestEffort() async {
    try {
      await saveBounds();
    } catch (_) {
      // Window geometry is best-effort and must never block hiding or exit.
    }
  }

  Future<void> setMinimizeToTray(bool value) async {
    minimizeToTray = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_minimizeToTrayKey, value);
  }

  /// Brings a hidden or minimized window back so the user can see the PIN
  /// screen. Best effort: desktop-only and must never block the lock path.
  Future<void> showAndFocus() async {
    if (!Platform.isWindows && !Platform.isMacOS && !Platform.isLinux) return;
    try {
      await windowManager.show();
      await windowManager.focus();
    } catch (_) {
      // The window may already be closing or the platform may not allow it.
    }
  }

  @override
  void onWindowClose() async {
    // Native close events can arrive more than once while asynchronous cleanup
    // is running. Claim the exit path before awaiting any platform calls.
    if (_closing) return;

    final preventClose = await windowManager.isPreventClose();
    if (_closing) return;
    if (preventClose && minimizeToTray && trayReady) {
      // The process remains alive while hidden, so persist geometry in the
      // background rather than making the close-to-tray gesture wait on disk
      // or platform-channel work.
      unawaited(_saveBoundsBestEffort());
      await windowManager.hide();
      return;
    }

    _closing = true;
    _saveBoundsTimer?.cancel();
    _saveBoundsTimer = null;

    // Decide to exit before awaiting persistence. Run bounds saving alongside
    // shutdown so a slow preferences write does not add its full latency to
    // the database/service cleanup path.
    final boundsSave = _saveBoundsBestEffort();
    final exit = onExit;
    try {
      if (exit != null) {
        await Future.wait<void>([boundsSave, exit()]);
      } else {
        await boundsSave;
      }
    } finally {
      // Even if persistence or service cleanup fails, never leave the native
      // window permanently protected from closing.
      try {
        await windowManager.setPreventClose(false);
      } finally {
        await windowManager.destroy();
      }
    }
  }

  void _scheduleSaveBounds() {
    _saveBoundsTimer?.cancel();
    _saveBoundsTimer = Timer(const Duration(milliseconds: 350), () {
      unawaited(saveBounds().catchError((Object _) {}));
    });
  }

  @override
  void onWindowResize() => _scheduleSaveBounds();

  @override
  void onWindowMove() => _scheduleSaveBounds();

  void dispose() {
    _saveBoundsTimer?.cancel();
    _saveBoundsTimer = null;
    windowManager.removeListener(this);
  }
}
