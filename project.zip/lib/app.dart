import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'features/dashboard/presentation/dashboard_page.dart';
import 'features/my_day/presentation/my_day_page.dart';
import 'features/calendar/presentation/calendar_page.dart';
import 'features/events/presentation/events_page.dart';
import 'features/planning_intelligence/presentation/planning_page.dart';
import 'features/projects/presentation/projects_page.dart';
import 'features/tasks/presentation/tasks_page.dart';
import 'features/habits/presentation/habits_page.dart';
import 'features/focus/presentation/focus_page.dart';
import 'features/diary/presentation/diary_page.dart';
import 'features/insights/presentation/insights_page.dart';
import 'features/settings/presentation/settings_page.dart';
import 'features/command_palette/presentation/command_palette.dart';
import 'features/quick_capture/presentation/quick_capture_dialog.dart';
import 'features/app_lock/presentation/app_lock_gate.dart';
import 'features/app_lock/providers/app_lock_controller.dart';
import 'core/providers/quick_capture_provider.dart';
import 'core/providers/service_providers.dart';
import 'core/services/error_log_service.dart';
import 'core/providers/theme_provider.dart';
import 'core/providers/navigation_provider.dart';
import 'core/providers/command_action_provider.dart';
import 'core/theme/app_theme.dart';

class LocusApp extends ConsumerWidget {
  const LocusApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);

    return MaterialApp(
      title: 'Locus',
      debugShowCheckedModeBanner: false,
      themeMode: themeMode,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      // The gate sits above the Navigator so dialogs and pushed routes cannot
      // appear above the lock screen, and the shell is never disposed when the
      // lock engages.
      builder: (context, child) =>
          AppLockGate(child: child ?? const SizedBox.shrink()),
      home: const _MainScaffold(),
    );
  }
}

class _MainScaffold extends ConsumerStatefulWidget {
  const _MainScaffold();

  @override
  ConsumerState<_MainScaffold> createState() => _MainScaffoldState();
}

class _MainScaffoldState extends ConsumerState<_MainScaffold> {
  final _quickCaptureDialogGate = QuickCaptureDialogGate();
  bool _pendingQuickCapture = false;

  final _pages = const [
    DashboardPage(),
    MyDayPage(),
    EventsPage(),
    ProjectsPage(),
    TasksPage(),
    HabitsPage(),
    FocusPage(),
    DiaryPage(),
    InsightsPage(),
    SettingsPage(),
    CalendarPage(),
    PlanningPage(),
  ];

  void _openCommandPalette() {
    showCommandPalette(
      context,
      onNavigate: (index) {
        ref.read(navigationIndexProvider.notifier).setIndex(index);
      },
      onQuickCapture: _openQuickCaptureAfterFrame,
    );
  }

  void _goTo(int index) {
    ref.read(navigationIndexProvider.notifier).setIndex(index);
  }

  Future<void> _showQuickCaptureSafely() async {
    try {
      await showQuickCaptureDialog(context);
    } catch (error, stack) {
      await ErrorLogService.log(error, stack);
    } finally {
      _quickCaptureDialogGate.release();
    }
  }

  void _openQuickCaptureAfterFrame() {
    if (!_quickCaptureDialogGate.tryAcquire()) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        _quickCaptureDialogGate.release();
        return;
      }
      unawaited(_showQuickCaptureSafely());
    });
  }

  @override
  Widget build(BuildContext context) {
    final index = ref.watch(navigationIndexProvider);
    ref.listen<int>(quickCaptureRequestProvider, (previous, next) {
      if (next <= (previous ?? 0)) return;
      final lock = ref.read(appLockControllerProvider).valueOrNull;
      if (lock == null || lock.locked) {
        // Keep the request instead of opening a dialog underneath the PIN
        // screen. The lock listener below opens it after a successful unlock.
        _pendingQuickCapture = true;
        unawaited(ref.read(windowServiceProvider).showAndFocus());
        return;
      }
      _openQuickCaptureAfterFrame();
    });
    ref.listen<AsyncValue<AppLockState>>(appLockControllerProvider, (
      previous,
      next,
    ) {
      final lock = next.valueOrNull;
      if (!_pendingQuickCapture || lock == null || lock.locked) return;
      _pendingQuickCapture = false;
      _openQuickCaptureAfterFrame();
    });
    return CallbackShortcuts(
      bindings: {
        // Ctrl + K opens the command palette.
        const SingleActivator(LogicalKeyboardKey.keyK, control: true):
            _openCommandPalette,
        // Ctrl + Shift + N opens the quick-add to-do flow.
        const SingleActivator(
          LogicalKeyboardKey.keyN,
          control: true,
          shift: true,
        ): () {
          _goTo(NavPage.tasks);
          ref
              .read(commandActionProvider.notifier)
              .dispatch(CommandAction.newTask);
        },
        // Keyboard-first navigation for desktop users.
        const SingleActivator(LogicalKeyboardKey.digit1, control: true): () =>
            _goTo(0),
        const SingleActivator(LogicalKeyboardKey.digit2, control: true): () =>
            _goTo(1),
        const SingleActivator(LogicalKeyboardKey.digit3, control: true): () =>
            _goTo(2),
        const SingleActivator(LogicalKeyboardKey.digit4, control: true): () =>
            _goTo(3),
        const SingleActivator(LogicalKeyboardKey.digit5, control: true): () =>
            _goTo(4),
        const SingleActivator(LogicalKeyboardKey.digit6, control: true): () =>
            _goTo(5),
        const SingleActivator(LogicalKeyboardKey.digit7, control: true): () =>
            _goTo(6),
        const SingleActivator(LogicalKeyboardKey.digit8, control: true): () =>
            _goTo(7),
        const SingleActivator(LogicalKeyboardKey.digit9, control: true): () =>
            _goTo(8),
        const SingleActivator(LogicalKeyboardKey.digit0, control: true): () =>
            _goTo(9),
        // Calendar is the appended stable page 10.
        const SingleActivator(
          LogicalKeyboardKey.keyC,
          control: true,
          alt: true,
        ): () =>
            _goTo(NavPage.calendar),
        const SingleActivator(
          LogicalKeyboardKey.keyP,
          control: true,
          alt: true,
        ): () =>
            _goTo(NavPage.planning),
      },
      child: Focus(
        autofocus: true,
        child: Scaffold(
          body: LayoutBuilder(
            builder: (context, constraints) {
              final wide = constraints.maxWidth >= 1100;
              return Row(
                children: [
                  NavigationRail(
                    extended: wide,
                    selectedIndex: index,
                    minWidth: 76,
                    minExtendedWidth: 224,
                    onDestinationSelected: (i) =>
                        ref.read(navigationIndexProvider.notifier).setIndex(i),
                    leading: Padding(
                      padding: const EdgeInsets.fromLTRB(12, 16, 12, 12),
                      child: SizedBox(
                        width: wide ? 200 : 52,
                        child: Column(
                          children: [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 4,
                                ),
                                child: Text(
                                  'Locus',
                                  style: TextStyle(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.onSurface,
                                    fontSize: 24,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -0.5,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            if (wide)
                              SizedBox(
                                width: double.infinity,
                                child: FilledButton.tonalIcon(
                                  onPressed: _openCommandPalette,
                                  icon: const Icon(Icons.search, size: 18),
                                  label: const Text('Search  Ctrl+K'),
                                  style: FilledButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 10,
                                    ),
                                    alignment: Alignment.centerLeft,
                                  ),
                                ),
                              )
                            else
                              IconButton(
                                tooltip: 'Command Palette (Ctrl+K)',
                                icon: const Icon(Icons.search),
                                onPressed: _openCommandPalette,
                              ),
                          ],
                        ),
                      ),
                    ),
                    groupAlignment: -0.72,
                    destinations: const [
                      NavigationRailDestination(
                        icon: Icon(Icons.dashboard_outlined),
                        label: Text('Today'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.wb_sunny_outlined),
                        label: Text('My Day'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.event_outlined),
                        label: Text('Events'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.folder_outlined),
                        label: Text('Projects'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.checklist_outlined),
                        label: Text('To-do'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.check_circle_outlined),
                        label: Text('Habits'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.timer_outlined),
                        label: Text('Focus'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.book_outlined),
                        label: Text('Diary'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.insights_outlined),
                        label: Text('Insights'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.settings_outlined),
                        label: Text('Settings'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.calendar_month_outlined),
                        label: Text('Calendar'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.lightbulb_outline),
                        label: Text('Planning'),
                      ),
                    ],
                  ),
                  const VerticalDivider(width: 1),
                  Expanded(
                    child: IndexedStack(index: index, children: _pages),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
