import java.util.Properties

plugins {
    id("com.android.application")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

// Release signing comes from android/key.properties (never committed) or, in
// CI, from LOCUS_* environment variables. Without either, release builds are
// signed with the debug key so `flutter build apk --release` still works for
// local testing; an APK built that way must not be distributed.
val keystoreProperties = Properties().apply {
    val file = rootProject.file("key.properties")
    if (file.exists()) file.inputStream().use { load(it) }
}

fun signingSetting(property: String, environment: String): String? =
    (keystoreProperties.getProperty(property) ?: System.getenv(environment))
        ?.takeIf { it.isNotBlank() }

val releaseStoreFile = signingSetting("storeFile", "LOCUS_KEYSTORE_FILE")
val releaseStorePassword = signingSetting("storePassword", "LOCUS_KEYSTORE_PASSWORD")
val releaseKeyAlias = signingSetting("keyAlias", "LOCUS_KEY_ALIAS")
val releaseKeyPassword = signingSetting("keyPassword", "LOCUS_KEY_PASSWORD")
val hasReleaseSigning = listOf(
    releaseStoreFile,
    releaseStorePassword,
    releaseKeyAlias,
    releaseKeyPassword,
).all { it != null }

// A release task must never silently fall back to the Android debug key.
// Local/CI build checks that intentionally use the debug key must opt in:
//   flutter build apk --release --android-project-arg=locus.allowDebugSigned=true
// or set ORG_GRADLE_PROJECT_locus.allowDebugSigned=true.
val isReleaseTask = gradle.startParameter.taskNames.any {
    it.contains("Release", ignoreCase = true)
}
val allowDebugSigned =
    (project.findProperty("locus.allowDebugSigned") as String?)?.toBoolean()
        ?: (System.getenv("LOCUS_ALLOW_DEBUG_SIGNING") == "true")
if (isReleaseTask && !hasReleaseSigning && !allowDebugSigned) {
    throw GradleException(
        "Release signing is not configured. Add android/key.properties or the " +
            "LOCUS_KEYSTORE_FILE/LOCUS_KEYSTORE_PASSWORD/LOCUS_KEY_ALIAS/" +
            "LOCUS_KEY_PASSWORD environment variables. For a throwaway build, " +
            "pass -Plocus.allowDebugSigned=true. See docs/ANDROID_RELEASE.md."
    )
}

android {
    namespace = "com.locusplanner.app"
    compileSdk = 36
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    sourceSets {
        getByName("main") {
            // Bundled SQLite3MultipleCiphers libraries. They are loaded by
            // name from `Sqlite3mcLoader` only when live encryption is on.
            jniLibs.srcDir(rootProject.file("../third_party/sqlite3mc/android"))
        }
    }

    defaultConfig {
        // The installed app's identity. Changing it later makes Android treat
        // the app as a different one (no in-place update, separate data), so
        // set it to an ID you own before the first real install. The namespace
        // above and this ID are intentionally the same so the manifest,
        // Kotlin package and plugin registration all agree.
        applicationId = "com.locusplanner.app"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        // Uses the version code from pubspec.yaml. When using split APKs, 1000 * ABI_VERSION
        // is added automatically by Flutter. (https://developer.android.com/studio/build/configure-apk-splits#configure-APK-versions)
        // You can force using the value of versionCode by specifying the `-P force-version-code-ignoring-abi=true`
        // flag during build.
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file(releaseStoreFile!!)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            signingConfig = if (hasReleaseSigning) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
            // Shrink the 89 MB universal APK and remove unused resources. The
            // release checklist requires testing reminders, boot re-arm, the
            // widget, QR scan, sync and encryption on a minified build.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}
